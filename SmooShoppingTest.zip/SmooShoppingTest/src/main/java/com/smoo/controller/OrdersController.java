package com.smoo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.smoo.bean.Address;
import com.smoo.bean.Orders;
import com.smoo.mapper.OrdersMapper;

@Controller
public class OrdersController {

	@Autowired
	private OrdersMapper ordersMapper;
	private String json;

	public String getJson() {
		return json;
	}

	public void setJson(String json) {
		this.json = json;
	}

	public void setOrdersMapper(OrdersMapper ordersMapper) {
		this.ordersMapper = ordersMapper;
	}
	
	/*//��ѯ�û�����
	@ResponseBody
	@RequestMapping(value="/findCartId",produces = "text/html;charset=utf-8")
	public String findCartId(int oid) {
		List<Orders> findOrderId = ordersMapper.findOrderId(oid);
		json=JSON.toJSONString(findOrderId);
		return json;
	}
	//�����û�����
	@RequestMapping(value="/addOrder",produces = "text/html;charset=utf-8")
	public String addOrder(Orders orders) {
		ordersMapper.addOrder(orders);
		return "findUserId";
	}
	//�޸��û�����
	@RequestMapping(value="/updateOrder",produces = "text/html;charset=utf-8")
	public String updateOrder(Orders orders) {
		orders.setAid(orders.getAid());
		orders.setAddress(orders.getAddress());
		orders.setStuff(orders.getStuff());
		ordersMapper.updateOrder(orders);
		return "findUserId";
	}*/
}
