package com.smoo.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smoo.bean.Cart;
import com.smoo.mapper.CartMapper;

@Controller
public class CartController {
	
	@Autowired
	private CartMapper cartMapper;
	private String json;

	public void setCartMapper(CartMapper cartMapper) {
		this.cartMapper = cartMapper;
	}
	
	public String getJson() {
		return json;
	}

	public void setJson(String json) {
		this.json = json;
	}

	//��ѯ�û�Ϊx�Ĺ��ﳵ
	@ResponseBody
	@RequestMapping(value="/findCartId",produces = "text/html;charset=utf-8")
	public String findCartId(int uid) {
		System.out.println(uid);
		List<Cart> findCartId = cartMapper.findCartId(uid);
		json=JSON.toJSONString(findCartId);
		System.out.println(json);
		return json;
	}
	//�������ﳵ
	@RequestMapping(value="/addCart",produces = "text/html;charset=utf-8")
	@ResponseBody
	public String addCart(Cart cart) {
		cartMapper.addCart(cart);
		return "jsonString";
	}
	//ɾ�����ﳵ
	@JsonIgnore
	@RequestMapping(value="/deleteCart",produces = "text/html;charset=utf-8")
	public String deleteCart(int cid) {
		cartMapper.deleteCart(cid);
		return "index";
	}
	//�޸Ĺ��ﳵ����
/*	@RequestMapping(value="/updateCart",produces = "text/html;charset=utf-8")
	public String updateCart(Cart cart) {
		cart.setSid(cart.getSid());
		cart.setCnum(cart.getCnum());
		cart.setCmoney(cart.getCmoney());
		cart.setUid(cart.getUid());
		cartMapper.updateCart(cart);
		return "findUserId";
	}*/
}
