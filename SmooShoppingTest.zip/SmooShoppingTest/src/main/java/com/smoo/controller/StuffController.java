package com.smoo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smoo.bean.Stuff;
import com.smoo.mapper.StuffMapper;
import com.smoo.util.Page;
import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Controller
public class StuffController {
	
	@Autowired
	private StuffMapper stuffMapper;
	private String json;
	
	public void setStuffMapper(StuffMapper stuffMapper) {
		this.stuffMapper = stuffMapper;
	}
	
	public String getJson() {
		return json;
	}

	public void setJson(String json) {
		this.json = json;
	}

	//��ѯ������Ʒ
	@ResponseBody
	@RequestMapping(value="/findStuffAll",produces = "text/html;charset=utf-8")
	public String findStuffAll() {
		List<Stuff> findStuffAll = stuffMapper.findStuffAll();
		json=JSON.toJSONString(findStuffAll);
		return json;
	}
	//��ѯ������Ʒ
	@ResponseBody
	@RequestMapping(value="/findStuffId",produces = "text/html;charset=utf-8")
	public String findStuffId(int sid) {
		System.out.println(sid);
		List<Stuff> findStuffId = stuffMapper.findStuffId(sid);
		System.out.println(findStuffId);
		json=JSON.toJSONString(findStuffId);
		return json;
	}
	//�����ѯ
	@ResponseBody
	@RequestMapping(value="/find6",produces = "text/html;charset=utf-8")
	public String find6() {
		List<Stuff> find6 = stuffMapper.find6();
		json=JSON.toJSONString(find6);
		return json;
	}
	//ģ����ѯ
	@ResponseBody
	@RequestMapping(value="/findKey",produces = "text/html;charset=utf-8")
	public String findKey(String key) {
		System.out.println(key);
		List<Stuff> findKey = stuffMapper.findKey(key);
		json=JSON.toJSONString(findKey);
		return json;
	}
}
