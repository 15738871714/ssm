package com.smoo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.smoo.bean.Address;
import com.smoo.mapper.AddressMapper;

@Controller
public class AddressController {

	@Autowired
	private AddressMapper addressMapper;
	private String json;
	
	public String getJson() {
		return json;
	}

	public void setJson(String json) {
		this.json = json;
	}

	public void setAddressMapper(AddressMapper addressMapper) {
		this.addressMapper = addressMapper;
	}
	
	//��ѯ�Լ����е�ַ
	@ResponseBody
	@RequestMapping(value="/findAddresId",produces = "text/html;charset=utf-8")
	public String findAddresId(int uid,Model model) {
		List<Address> findAddressId = addressMapper.findAddressId(uid);
		json=JSON.toJSONString(findAddressId);
		return json;
	}
	//���ӵ�ַ
	@RequestMapping(value="/addAddress")
	public String addAddress(Address address) {
		addressMapper.addAddress(address);
		return "findAddressId";
	}
	//ɾ����ַ
	@RequestMapping(value="/deleteAddress")
	public String deleteAddress(int aid) {
		addressMapper.deleteAddress(aid);
		return "findAddressId";
	}
	//���µ�ַ
	@RequestMapping(value="/updateAddress")
	public String updateAddress(Address address) {
		address.setaName(address.getaName());
		address.setaPhone(address.getaPhone());
		address.setaAddress(address.getaAddress());
		addressMapper.updateAddress(address);
		return "findAddressId";
	}
}
