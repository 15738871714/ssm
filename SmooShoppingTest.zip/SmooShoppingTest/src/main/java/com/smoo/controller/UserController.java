package com.smoo.controller;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSON;
import com.smoo.bean.User;
import com.smoo.mapper.UserMapper;

@Controller
public class UserController {
	
	@Autowired
	private UserMapper usermapper;
	private String json;

	public String getJson() {
		return json;
	}

	public void setJson(String json) {
		this.json = json;
	}

	public void setUsermapper(UserMapper usermapper) {
		this.usermapper = usermapper;
	}

	//��¼��֤
	/*@ResponseBody*/
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(@RequestParam("userName")String userName,@RequestParam("pwd")String pwd,Model model,HttpSession session) {
		User user = usermapper.login(userName, pwd);
		/*json=JSON.toJSONString(user);*/
		if(user!=null) {
			session.setAttribute("users", user);
			return "successindex";
		}
		return "index";
	}
	//�鿴��������
/*	@RequestMapping(value="/findUserId")
	public String findUserId(String userName,Model model) {
		
		return "people";
	}*/
	@RequestMapping("/people")
	public String hrefpage(){
		
		return "people";
	}
	//ע��
	@RequestMapping(value="/reg")
	public String reg(User user) {
		usermapper.reg(user);
		return "index";
	}
	// ע��
	@RequestMapping("/outLogin")
	public String outLogin(HttpSession session) {
		session.invalidate();
		System.out.println("��ʼע��");
		return "index";
	}	
	//�޸�    
	 @RequestMapping("/update")  
	    public String updateUser(User user,HttpSession session){
		 usermapper.update(user);
		 session.setAttribute("users", user);
		System.out.println(session);
			return "successindex";  
	 } 
}
