package com.smoo.bean;

public class Cart {
	private int cid;
	private int sid;
	private int uid;
	private int cNum;
	private float cMoney;
	private Stuff stuff;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	
	public Stuff getStuff() {
		return stuff;
	}
	public void setStuff(Stuff stuff) {
		this.stuff = stuff;
	}
	public int getcNum() {
		return cNum;
	}
	public void setcNum(int cNum) {
		this.cNum = cNum;
	}
	public float getcMoney() {
		return cMoney;
	}
	public void setcMoney(float cMoney) {
		this.cMoney = cMoney;
	}
	@Override
	public String toString() {
		return "Cart [cid=" + cid + ", sid=" + sid + ", uid=" + uid + ", cNum=" + cNum + ", cMoney=" + cMoney
				+ ", stuff=" + stuff + "]";
	}
	

	
}
