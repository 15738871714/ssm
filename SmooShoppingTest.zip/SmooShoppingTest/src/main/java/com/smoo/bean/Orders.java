package com.smoo.bean;

public class Orders {
	private int oid;
	private int cid;
	private int uid;
	private int aid;
	private Address address;
	private User user;
	private Stuff stuff;
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Stuff getStuff() {
		return stuff;
	}
	public void setStuff(Stuff stuff) {
		this.stuff = stuff;
	}
	@Override
	public String toString() {
		return "Order [oid=" + oid + ", cid=" + cid + ", uid=" + uid + ", aid=" + aid + ", address=" + address
				+ ", user=" + user + ", stuff=" + stuff + "]";
	}
	
	
}
