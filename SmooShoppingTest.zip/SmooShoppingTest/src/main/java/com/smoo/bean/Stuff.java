package com.smoo.bean;

public class Stuff {
	private int sid;
	private String sTitle;
	private String sName;
	private float sMoney;
	private String sContext;
	private String yesOrNo;
	private String sImage;
	
	public String getsImage() {
		return sImage;
	}
	public void setsImage(String sImage) {
		this.sImage = sImage;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getsTitle() {
		return sTitle;
	}
	public void setsTitle(String sTitle) {
		this.sTitle = sTitle;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public float getsMoney() {
		return sMoney;
	}
	public void setsMoney(float sMoney) {
		this.sMoney = sMoney;
	}
	public String getsContext() {
		return sContext;
	}
	public void setsContext(String sContext) {
		this.sContext = sContext;
	}
	public String getYesOrNo() {
		return yesOrNo;
	}
	public void setYesOrNo(String yesOrNo) {
		this.yesOrNo = yesOrNo;
	}
	@Override
	public String toString() {
		return "Stuff [sid=" + sid + ", sTitle=" + sTitle + ", sName=" + sName + ", sMoney=" + sMoney + ", sContext="
				+ sContext + ", yesOrNo=" + yesOrNo + ", sImage=" + sImage + "]";
	}
	
	
}
