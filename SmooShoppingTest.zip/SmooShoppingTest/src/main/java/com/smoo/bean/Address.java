package com.smoo.bean;

public class Address {
	private int aid;
	private String aName;
	private int aPhone;
	private String aAddress;
	private int uid;
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getaName() {
		return aName;
	}
	public void setaName(String aName) {
		this.aName = aName;
	}
	public int getaPhone() {
		return aPhone;
	}
	public void setaPhone(int aPhone) {
		this.aPhone = aPhone;
	}
	public String getaAddress() {
		return aAddress;
	}
	public void setaAddress(String aAddress) {
		this.aAddress = aAddress;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	@Override
	public String toString() {
		return "Address [aid=" + aid + ", aName=" + aName + ", aPhone=" + aPhone + ", aAddress=" + aAddress + ", uid="
				+ uid + "]";
	}
	
}
