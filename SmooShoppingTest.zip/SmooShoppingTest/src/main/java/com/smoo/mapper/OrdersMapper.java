package com.smoo.mapper;

import java.util.List;

import com.smoo.bean.Orders;

public interface OrdersMapper {
	List<Orders>  findOrderId(int oid);
	void addOrder(Orders orders);
	void deleteOrder(int oid);
	void updateOrder(Orders orders);
}
