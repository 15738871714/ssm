package com.smoo.mapper;

import java.util.List;

import com.smoo.bean.Cart;

public interface CartMapper {
	List<Cart> findCartId(int uid);
	List<Cart> findCartAll();
	void addCart(Cart cart);
	void deleteCart(int cid);
	void updateCart(Cart cart);

}
