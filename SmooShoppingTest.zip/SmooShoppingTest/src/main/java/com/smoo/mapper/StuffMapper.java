package com.smoo.mapper;

import java.util.List;

import com.smoo.bean.Stuff;

public interface StuffMapper {
	List<Stuff> findStuffAll();
	List<Stuff> findStuffId(int sid);
	List<Stuff> findByPage();
	List<Stuff> find6();
	List<Stuff> findKey(String key);
}
