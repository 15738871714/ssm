package com.smoo.mapper;

import java.util.List;

import com.smoo.bean.Address;

public interface AddressMapper {
	/*List<Address> findAddressAll();*/
	List<Address> findAddressId(int uid);
	void addAddress(Address address);
	void deleteAddress(int aid);
	void updateAddress(Address address);
}
