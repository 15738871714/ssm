package com.smoo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smoo.bean.User;

public interface UserMapper {
		User login(@Param("userName")String userName,@Param("pwd")String pwd);
		List<User>findUserId(String userName);
		void reg(User user);
		boolean update(User user); 
}
