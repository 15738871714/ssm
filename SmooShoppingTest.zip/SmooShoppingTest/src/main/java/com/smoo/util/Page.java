package com.smoo.util;

public class Page {

	int start=0;
	int count = 5;
	int last = 0;
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getLast() {
		return last;
	}
	public void setLast(int last) {
		this.last = last;
	}
	
	public void caculateLast(int total) {
	    // 鍋囪鎬绘暟鏄�50锛屾槸鑳藉琚�5鏁撮櫎鐨勶紝閭ｄ箞鏈�鍚庝竴椤电殑寮�濮嬪氨鏄�45
	    if (0 == total % count)
	        last = total - count;
	    // 鍋囪鎬绘暟鏄�51锛屼笉鑳藉琚�5鏁撮櫎鐨勶紝閭ｄ箞鏈�鍚庝竴椤电殑寮�濮嬪氨鏄�50
	    else
	        last = total - total % count;		
	}

	
	
	
}
