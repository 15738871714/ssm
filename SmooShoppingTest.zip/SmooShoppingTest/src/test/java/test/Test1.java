package test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smoo.bean.Stuff;
import com.smoo.mapper.StuffMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:spring-mvc-servlet.xml"})
public class Test1 {
	@Autowired
	private StuffMapper stuffMapper;
	@Test
	public void test1() {
		PageHelper.offsetPage(0, 9);
		System.out.println("1");
		List<Stuff> findStuffAll = stuffMapper.findStuffAll();
		System.out.println("2");
			System.out.println("3");
			int total =(int) new PageInfo<Stuff>(findStuffAll).getTotal();
			System.out.println(total);
			System.out.println(findStuffAll);
	}
	
	
	@Test
	public void test2() {
		List<Stuff> findStuffAll = stuffMapper.findStuffAll();
		System.out.println(findStuffAll);
	}

}
